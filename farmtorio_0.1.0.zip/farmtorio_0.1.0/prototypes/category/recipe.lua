data:extend(
    {
        {
            type= "recipe-category",
            name = "farmcraft"
        },
        
        {
            type= "recipe-category",
            name = "windmill"
        },
    }
)