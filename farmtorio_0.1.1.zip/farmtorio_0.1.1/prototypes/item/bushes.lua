data:extend({
  
{
    type = "item",
    name = "ironorebush",
    icon = "__farmtorio__/graphics/icons/ironorebush.png",
    flags = {"goes-to-quickbar"},
    subgroup = "bushes-subgroup",
    order = "a[ironorebush]",
    place_result = "ironorebush",
    stack_size = 200
}
    
    
})