data:extend(
    {
      {
    type = "item-subgroup",
    name = "food",
    group = "intermediate-products",
    order = "h"
  },
  
        {
    type = "item-subgroup",
    name = "forestry",
    group = "production",
    order = "g"
  }
}
)