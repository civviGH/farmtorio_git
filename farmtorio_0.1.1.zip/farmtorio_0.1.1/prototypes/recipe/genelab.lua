data:extend({
    {
     type = "recipe",
     name = "ironorebush",
     enabled = "false",   
     energy_required = 2,
     category = "genelab",
     subgroup = "bushes-subgroup",
     ingredients = 
     {
        {"iron-ore", 1}
     },
     result = "ironorebush"
    }
}
)
